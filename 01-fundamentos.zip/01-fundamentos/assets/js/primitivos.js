let nombre = 'Peter Parker';
console.log(nombre);

nombre = 'Ben Parker';
console.log(nombre);

nombre = 'Tia Mey';
nombre = "Tia May";

console.log(typeof nombre);

nombre = 123;
console.log(typeof nombre);

let esMarvel = false;
console.log(typeof esMarverl);

let edad = 33;
console.log(typeof edad);

edad = 22.33; 
console.log(typeof edad);

let superPoder;
console.log(typeof superPoder);

// Null es un primitivo y no un Objeto, ya que en consolo se imprime como un objeto
let soyNull = null;
console.log(soyNull);

// Symbol, permite crear identificadores únicos 

let symboll = Symbol ('a');
let symbol2 = Symbol ('a');
console.log(typeof symbol1);
console.log(symbol1 === symbol2);


