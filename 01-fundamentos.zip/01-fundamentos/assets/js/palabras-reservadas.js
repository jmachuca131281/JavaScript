// Se aconseja de poner (-) para que lo reconozca los servidores.
console.log('Hola mundo');

// Palabras reservadas, verificar la lista pdf.
// Verificar la página web del curso session 3.
