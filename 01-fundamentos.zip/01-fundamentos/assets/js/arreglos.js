// const arr = new Array(10);
// const arr = [];
// console.log(arr);

let videoJuegos = ['Mario 3', 'Megaman', 'Chrono Triger'];
console.log({ videoJuegos });
console.log(videoJuegos[0]);

let arregloCosas = [
    true,
    false,
    123,
    'Jose Manuel',
    1 * 2,
    function(){},
    ()=>{},
    { a: 1},
    ['Mario 3', 'Megaman', 'Chrono Triger'],
];

console.log({arregloCosas});
console.log(arregloCosas[2]);
console.log(arregloCosas[8][2]);